package promotion;

public class Performance {
	
	public void exam()
	{
		System.out.println("Worker promoted after qualifiying written exam and on performance basis :");
	}
	

}
