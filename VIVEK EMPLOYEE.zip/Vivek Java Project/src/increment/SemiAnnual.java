package increment;

public class SemiAnnual extends Annual{
	
	public void semiAnnualIncrement()
	{
		System.out.println("Worker get semi annual increment on performance basis :");
	}
	

}
