package increment;

public class Annual {
	
	public void annualIncrement()
	{
		System.out.println("Every worker gets annual Increment as on 31st Dec every year. ");
	}
	

	
	

}
