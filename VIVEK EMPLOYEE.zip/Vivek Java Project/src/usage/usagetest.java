
package usage;


import employee.Executive;
import employee.Manager;
import employee.Worker;
import hra.Allowance;
import increment.SemiAnnual;
import promotion.Performance;
import salary.Monthly;
import termination.Misconduct;

public class usagetest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.out.println("*****************Welcome to the world of corporate***************");
		System.out.println("\n");
		Executive e = new Executive();
		e.work();e.manage();e.execute();
		System.out.println("******************************************************************");
		System.out.println("\n");
		Allowance a = new Allowance();
		a.lease();
		System.out.println("******************************************************************");
		
		System.out.println("\n");
		SemiAnnual sa = new SemiAnnual();
		sa.semiAnnualIncrement();
		sa.annualIncrement();
		System.out.println("******************************************************************");
		System.out.println("\n");
		Performance pa = new Performance();
		pa.exam();
		System.out.println("******************************************************************");
		System.out.println("\n");
		Monthly ma = new Monthly();
		ma.salary();
		ma.Perk();
		
		System.out.println("******************************************************************");
		System.out.println("\n");
		Misconduct mi = new Misconduct();
		mi.fire();
		System.out.println("******************************************************************");
		System.out.println("\n");
		System.out.println("***************    KHATAM     *********************");
		
		
		

	}

}
