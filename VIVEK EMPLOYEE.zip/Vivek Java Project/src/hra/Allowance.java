package hra;

public class Allowance {

	public void lease()
	{
		System.out.println("Worker get HRA for accomadation expenses :");
	}
	
}
