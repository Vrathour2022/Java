
package employee;

public class Worker {
	
	public void work()
	{
		System.out.println("Worker work for the company :");
	}
	

}
