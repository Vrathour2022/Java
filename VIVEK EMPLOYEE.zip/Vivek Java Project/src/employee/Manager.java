package employee;

public class Manager extends Worker {
	
	public void manage()
	{
		System.out.println("Manager manages and work for the company :");
	}
	

}
