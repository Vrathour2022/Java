package employee;

public class Executive extends Manager {
	
	public void execute()
	{
		System.out.println("Executive is responsible for financial activities :");
	}
	

}
