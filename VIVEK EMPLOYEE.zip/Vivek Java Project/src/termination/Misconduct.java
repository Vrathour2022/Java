package termination;

public class Misconduct {
	public void fire()
	{
		System.out.println("Worker got termination on major misconduct :");
	}
	

}
