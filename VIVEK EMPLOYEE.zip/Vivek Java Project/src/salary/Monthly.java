package salary;

public class Monthly extends Bonus {

	public void salary()
	{
		System.out.println("Salry credited to the salary account on 25th of every month :");
	}
	
}
