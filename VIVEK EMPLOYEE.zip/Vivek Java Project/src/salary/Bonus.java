package salary;

public class Bonus {

	public void Perk()
	{
		System.out.println("Employee get Bonus every quarter on company profit result :");
	}
	
}
